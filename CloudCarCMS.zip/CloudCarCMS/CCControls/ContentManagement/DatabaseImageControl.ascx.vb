﻿Namespace CCControls.ContentManagement

    Partial Public Class DatabaseImageControl
        Inherits UserControl

        Protected Sub PageLoad(ByVal Sender As Object, ByVal E As EventArgs) Handles Me.Load

        End Sub

        Protected Sub btnGetImage_Command(ByVal Sender As Object, ByVal E As CommandEventArgs)

        End Sub
    End Class

End Namespace