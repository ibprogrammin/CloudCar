﻿Namespace CCFramework.Commerce

    Public Enum EPriceLevel
        Regular = 0
        Warehouse = 1
        Sales = 2
    End Enum

End Namespace