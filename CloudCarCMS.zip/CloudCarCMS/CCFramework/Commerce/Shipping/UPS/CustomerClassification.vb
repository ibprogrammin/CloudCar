﻿Namespace CCFramework.Commerce.Shipping.UPS

    Public Enum CustomerClassification
        Wholesale = 1
        Occasional = 3
        Retail = 4
    End Enum

End Namespace