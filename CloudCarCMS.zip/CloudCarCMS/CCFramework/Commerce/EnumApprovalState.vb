﻿Namespace CCFramework.Commerce

    Public Enum EApprovalState
        Pending = 0
        Approved = 1
        Declined = 2
    End Enum

End Namespace