﻿Namespace CCCommerce.Mobile
    Public Partial Class MobileThankYou
        Inherits Page

        Protected Sub PageLoad(ByVal Sender As Object, ByVal E As EventArgs) Handles Me.Load

        End Sub

    End Class
End NameSpace