﻿Imports CloudCar.CCFramework.Core

Namespace CCContentManagement.EventModule

    Partial Public Class Events
        Inherits CloudCarContentPage

        Public Sub New()
            MyBase.New()
            Permalink = Settings.EventPage
        End Sub

    End Class

End Namespace