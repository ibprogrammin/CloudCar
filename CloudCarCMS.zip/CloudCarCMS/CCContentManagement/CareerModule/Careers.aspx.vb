﻿Namespace CCContentManagement.CareerModule

    Public Class Careers
        Inherits Page

        Protected Sub PageLoad(ByVal Sender As Object, ByVal E As EventArgs) Handles Me.Load

        End Sub

    End Class

End Namespace